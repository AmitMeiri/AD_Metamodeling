# SuStaIn Real Data Analysis Package (ADNI Tau-PET)

This package contains all datasets, scripts, trained models, visual diagrams, and patient classifications for the unsupervised SuStaIn disease progression analysis on real ADNI Tau-PET scans.

---

## Package Contents

### 1. Data Files
* `ADNI_MASTER_ALL_SUBJECTS.csv`: Master clinical metadata, including diagnoses (`DX`), visit codes (`VISCODE2`), and demographics.
* `UCBERKELEY_TAU_6MM_06Sep2026.csv`: Desikan-Killiany (DK) ROI measurements (`_SUVR` and `_VOLUME`) referenced to inferior cerebellar gray matter.

### 2. Execution Scripts
* `run_sustain_real_data.py`: The complete end-to-end data pipeline. Groups 68 DK regions into 10 volume-weighted lobar ROIs, computes Z-scores against Healthy Controls (`DX == 'CN'`), runs 5-Fold Cross-Validation (CVIC) up to 6 subtypes, and trains the final model.
* `generate_clean_csvs.py`: Formats and exports the 1-based patient classifications for both 4- and 6-subtype models.
* `analyze_final_models.py`: Inspects the fitted MCMC sequence matrices and computes cross-tabulations.

### 3. Patient Classification Spreadsheets
* `real_data_classification_4subtypes.csv`: Per-scan classifications for the canonical **4-subtype model** (matching Vogel et al., 2021), with explicit labels for Stage 0 (Tau-Negative) and Subtypes 1-4.
* `real_data_classification_6subtypes.csv`: Per-scan classifications for the **6-subtype model** (data-driven global CVIC minimum), with explicit labels for Stage 0 (Tau-Negative) and Subtypes 1-6.

### 4. Detailed Documentation
* `real_data_methodology.md`: Mathematical methodology covering volume-weighted lobar aggregation, healthy control Z-scoring, and SuStaIn MCMC parameters.
* `real_data_subtypes_analysis.md`: In-depth analysis of the discovered biological trajectories, CVIC cross-validation scores, and comparison to Vogel's 4 published subtypes.

### 5. Output Artifacts Folder (`real_data_output/`)
* `pickle_files/`: All serialized Python pickle model artifacts across all 5 cross-validation folds and final full-dataset models (`subtype0` through `subtype5`).
* `adni_tau_real_subtype*_PVD.png_all-subtypes.png`: Positional Variance Diagrams (PVDs) visualizing the temporal biomarker cascades across subtypes.
* `real_data_classification.csv`: Raw output classification matrix.

---

## How to Run / Replicate
To rerun the pipeline in Python:
```bash
python run_sustain_real_data.py
```
